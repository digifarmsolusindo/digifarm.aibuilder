import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import { MainDashboard } from "./components/MainDashboard";
import { AccountPage } from "./components/AccountPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState<"dashboard" | "account">("dashboard");

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-yellow-50 via-amber-50 to-orange-50">
      <Authenticated>
        <header className="sticky top-0 z-10 bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 backdrop-blur-sm h-16 flex justify-between items-center shadow-lg px-4">
          <div className="flex items-center space-x-2">
            <div className="text-2xl">🐓</div>
            <h2 className="text-xl font-bold text-white">DIGIFARM.Lite</h2>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setCurrentPage(currentPage === "dashboard" ? "account" : "dashboard")}
              className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors"
            >
              {currentPage === "dashboard" ? "👤" : "🏠"}
            </button>
            <SignOutButton />
          </div>
        </header>
        <main className="flex-1 p-4">
          {currentPage === "dashboard" ? <MainDashboard /> : <AccountPage />}
        </main>
      </Authenticated>

      <Unauthenticated>
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4">🐓</div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-yellow-600 via-amber-600 to-orange-600 bg-clip-text text-transparent mb-2">
                DIGIFARM.Lite
              </h1>
              <p className="text-gray-600">Investasi Ternak Digital Ayam Petelur</p>
            </div>
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>

      <Toaster />
    </div>
  );
}
