import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface SettingsSectionProps {
  user: any;
}

export function SettingsSection({ user }: SettingsSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");
  const [showPasswordForm, setShowPasswordForm] = useState(false);

  const updateProfile = useMutation(api.users.updateProfile);

  const handleSaveProfile = async () => {
    try {
      await updateProfile({ name });
      setIsEditing(false);
      toast.success("Profil berhasil diperbarui!");
    } catch (error) {
      toast.error("Gagal memperbarui profil");
      console.error(error);
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-gray-800 mb-4">Pengaturan Akun</h3>
      
      {/* Profile Settings */}
      <div className="space-y-4">
        <div className="border-b border-gray-100 pb-4">
          <h4 className="font-medium text-gray-700 mb-3">Informasi Profil</h4>
          
          {/* Profile Photo */}
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 flex items-center justify-center text-white text-xl font-bold">
              {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
            </div>
            <button className="text-sm text-blue-600 hover:text-blue-700">
              Ganti Foto Profil
            </button>
          </div>
          
          {/* Name */}
          <div className="space-y-2">
            <label className="text-sm text-gray-600">Nama Lengkap</label>
            {isEditing ? (
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                />
                <button
                  onClick={handleSaveProfile}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600"
                >
                  Simpan
                </button>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setName(user?.name || "");
                  }}
                  className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
                >
                  Batal
                </button>
              </div>
            ) : (
              <div className="flex justify-between items-center">
                <span className="text-gray-800">{user?.name || "Belum diatur"}</span>
                <button
                  onClick={() => setIsEditing(true)}
                  className="text-sm text-blue-600 hover:text-blue-700"
                >
                  Edit
                </button>
              </div>
            )}
          </div>
          
          {/* Email */}
          <div className="space-y-2 mt-4">
            <label className="text-sm text-gray-600">Email</label>
            <div className="flex justify-between items-center">
              <span className="text-gray-800">{user?.email}</span>
              <span className="text-sm text-gray-500">(Tidak dapat diubah)</span>
            </div>
          </div>
        </div>

        {/* Password Settings */}
        <div className="border-b border-gray-100 pb-4">
          <h4 className="font-medium text-gray-700 mb-3">Keamanan</h4>
          
          {!showPasswordForm ? (
            <button
              onClick={() => setShowPasswordForm(true)}
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              Ganti Password
            </button>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="text-sm text-gray-600">Password Lama</label>
                <input
                  type="password"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                />
              </div>
              <div>
                <label className="text-sm text-gray-600">Password Baru</label>
                <input
                  type="password"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                />
              </div>
              <div>
                <label className="text-sm text-gray-600">Konfirmasi Password Baru</label>
                <input
                  type="password"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-transparent"
                />
              </div>
              <div className="flex space-x-2">
                <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 text-sm">
                  Simpan Password
                </button>
                <button
                  onClick={() => setShowPasswordForm(false)}
                  className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 text-sm"
                >
                  Batal
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Notification Settings */}
        <div>
          <h4 className="font-medium text-gray-700 mb-3">Notifikasi</h4>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-700">Email Notifikasi</span>
              <input type="checkbox" className="toggle" defaultChecked />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-700">Notifikasi Investasi</span>
              <input type="checkbox" className="toggle" defaultChecked />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-700">Notifikasi Promo</span>
              <input type="checkbox" className="toggle" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
