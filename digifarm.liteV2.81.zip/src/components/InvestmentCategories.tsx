interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
}

interface InvestmentCategoriesProps {
  categories: Category[];
  onCategorySelect: (categoryId: string) => void;
}

export function InvestmentCategories({ categories, onCategorySelect }: InvestmentCategoriesProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onCategorySelect(category.id)}
          className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-yellow-100 hover:border-yellow-300 group"
        >
          <div className="text-center space-y-3">
            <div className="text-4xl group-hover:scale-110 transition-transform duration-300">
              {category.icon}
            </div>
            <h3 className="font-bold text-gray-800 text-lg">{category.name}</h3>
            <p className="text-sm text-gray-600 leading-relaxed">{category.description}</p>
          </div>
        </button>
      ))}
    </div>
  );
}
