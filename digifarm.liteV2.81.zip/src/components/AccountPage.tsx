import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ProfileSection } from "./ProfileSection";
import { PortfolioSection } from "./PortfolioSection";
import { SettingsSection } from "./SettingsSection";
import { HelpSection } from "./HelpSection";

export function AccountPage() {
  const [activeSection, setActiveSection] = useState<"profile" | "portfolio" | "settings" | "help">("profile");
  const user = useQuery(api.users.getCurrentUser);

  const menuItems = [
    { id: "profile", label: "Profil", icon: "👤" },
    { id: "portfolio", label: "Portofolio", icon: "📊" },
    { id: "settings", label: "Pengaturan", icon: "⚙️" },
    { id: "help", label: "Bantuan", icon: "❓" },
  ];

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-yellow-100">
        <div className="text-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
            {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-1">
            {user?.name || "User"}
          </h2>
          <p className="text-gray-600">{user?.email}</p>
        </div>
      </div>

      {/* Menu Navigation */}
      <div className="bg-white rounded-2xl shadow-lg border border-yellow-100 overflow-hidden">
        <div className="grid grid-cols-2 gap-0">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id as any)}
              className={`p-4 text-center transition-colors ${
                activeSection === item.id
                  ? "bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-white"
                  : "bg-white text-gray-700 hover:bg-yellow-50"
              }`}
            >
              <div className="text-2xl mb-1">{item.icon}</div>
              <div className="text-sm font-medium">{item.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Content Section */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-yellow-100">
        {activeSection === "profile" && <ProfileSection user={user} />}
        {activeSection === "portfolio" && <PortfolioSection />}
        {activeSection === "settings" && <SettingsSection user={user} />}
        {activeSection === "help" && <HelpSection />}
      </div>
    </div>
  );
}
