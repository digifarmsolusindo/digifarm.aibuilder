import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface InvestmentVariantsProps {
  category: string;
  onBack: () => void;
  onVariantSelect: (variant: any) => void;
}

export function InvestmentVariants({ category, onBack, onVariantSelect }: InvestmentVariantsProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const variants = useQuery(api.investments.getInvestmentVariants, { category });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDuration = (days: number) => {
    if (days === 30) return "30 Hari (1 Bulan)";
    if (days === 90) return "90 Hari (3 Bulan)";
    if (days === 180) return "180 Hari (6 Bulan)";
    if (days === 365) return "365 Hari (12 Bulan)";
    return `${days} Hari`;
  };

  const nextVariant = () => {
    if (variants && currentIndex < variants.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const prevVariant = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  if (!variants || variants.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600">Memuat varian investasi...</p>
      </div>
    );
  }

  const currentVariant = variants[currentIndex];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center hover:shadow-lg transition-shadow"
        >
          ←
        </button>
        <h2 className="text-xl font-bold text-gray-800 capitalize">
          Paket {category === "junior" ? "Peternak Junior" : 
                category === "muda" ? "Peternak Muda" :
                category === "senior" ? "Peternak Senior" : "Juragan Ternak"}
        </h2>
      </div>

      <div className="relative">
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-yellow-100">
          <div className="space-y-4">
            <div className="text-center">
              <h3 className="text-lg font-bold text-gray-800 mb-2">
                {formatDuration(currentVariant.duration)}
              </h3>
              <div className="text-3xl mb-4">🐓</div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Pokok Investasi:</span>
                <span className="font-bold text-gray-800">{formatCurrency(currentVariant.principal)}</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-gray-600">Return:</span>
                <div className="text-right">
                  {currentVariant.hasPromo && (
                    <div className="text-sm text-gray-400 line-through">
                      {formatCurrency(currentVariant.oldReturn)}
                    </div>
                  )}
                  <div className="font-bold text-green-600 flex items-center">
                    {formatCurrency(currentVariant.newReturn)}
                    {currentVariant.hasPromo && (
                      <span className="ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                        PROMO
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-gray-600">Setara Dengan:</span>
                <span className="font-medium text-gray-800">
                  {currentVariant.chickens} Ekor Ayam Petelur & Paket Pakan {formatDuration(currentVariant.duration).split(" ")[2]}
                </span>
              </div>

              <div className="text-xs text-gray-500 bg-gray-50 p-3 rounded-lg">
                Termasuk biaya layanan dan asuransi kematian
              </div>
            </div>

            <button
              onClick={() => onVariantSelect(currentVariant)}
              className="w-full bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-white font-bold py-3 rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Pilih Paket Ini
            </button>
          </div>
        </div>

        {/* Navigation arrows */}
        <div className="flex justify-between items-center mt-4">
          <button
            onClick={prevVariant}
            disabled={currentIndex === 0}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
              currentIndex === 0
                ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                : "bg-white shadow-md hover:shadow-lg text-gray-700"
            }`}
          >
            ←
          </button>

          <div className="flex space-x-2">
            {variants.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? "bg-yellow-400" : "bg-gray-300"
                }`}
              />
            ))}
          </div>

          <button
            onClick={nextVariant}
            disabled={currentIndex === variants.length - 1}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
              currentIndex === variants.length - 1
                ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                : "bg-white shadow-md hover:shadow-lg text-gray-700"
            }`}
          >
            →
          </button>
        </div>
      </div>
    </div>
  );
}
