import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function PortfolioSection() {
  const investments = useQuery(api.investments.getUserInvestments);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDuration = (days: number) => {
    if (days === 30) return "1 Bulan";
    if (days === 90) return "3 Bulan";
    if (days === 180) return "6 Bulan";
    if (days === 365) return "12 Bulan";
    return `${days} Hari`;
  };

  const getCategoryName = (category: string) => {
    const names = {
      junior: "Peternak Junior",
      muda: "Peternak Muda",
      senior: "Peternak Senior",
      juragan: "Juragan Ternak",
    };
    return names[category as keyof typeof names] || category;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-700";
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "completed":
        return "bg-blue-100 text-blue-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return "Aktif";
      case "pending":
        return "Menunggu Pembayaran";
      case "completed":
        return "Selesai";
      default:
        return status;
    }
  };

  if (!investments || investments.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="text-6xl mb-4">📊</div>
        <h3 className="text-lg font-bold text-gray-800 mb-2">Belum Ada Investasi</h3>
        <p className="text-gray-600 mb-6">
          Anda belum memiliki investasi aktif. Mulai investasi ternak digital sekarang!
        </p>
        <button className="bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-white font-bold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300">
          Ternak Sekarang
        </button>
      </div>
    );
  }

  const totalInvestment = investments.reduce((sum, inv) => sum + inv.principal, 0);
  const totalReturn = investments.reduce((sum, inv) => sum + inv.returnAmount, 0);
  const activeInvestments = investments.filter(inv => inv.status === "active").length;

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-gray-800 mb-4">Portofolio Investasi</h3>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-xl">
          <div className="text-center">
            <p className="text-sm text-blue-600 mb-1">Total Investasi</p>
            <p className="text-lg font-bold text-blue-700">{formatCurrency(totalInvestment)}</p>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-xl">
          <div className="text-center">
            <p className="text-sm text-green-600 mb-1">Potensi Return</p>
            <p className="text-lg font-bold text-green-700">{formatCurrency(totalReturn)}</p>
          </div>
        </div>
      </div>

      {/* Saldo Return */}
      <div className="bg-gradient-to-r from-yellow-50 to-amber-50 p-4 rounded-xl border border-yellow-200">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-amber-600 mb-1">Saldo Return</p>
            <p className="text-xl font-bold text-amber-700">Rp 0</p>
          </div>
          <button
            disabled
            className="bg-gray-300 text-gray-500 px-4 py-2 rounded-lg cursor-not-allowed"
          >
            Tarik Saldo
          </button>
        </div>
      </div>

      {/* Investment List */}
      <div className="space-y-4">
        <h4 className="font-medium text-gray-700">Riwayat Investasi</h4>
        {investments.map((investment) => (
          <div key={investment._id} className="bg-gray-50 p-4 rounded-xl border">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h5 className="font-medium text-gray-800">
                  {getCategoryName(investment.category)}
                </h5>
                <p className="text-sm text-gray-600">
                  {formatDuration(investment.duration)} • {investment.chickens} Ekor
                </p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(investment.status)}`}>
                {getStatusText(investment.status)}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Investasi</p>
                <p className="font-medium">{formatCurrency(investment.principal)}</p>
              </div>
              <div>
                <p className="text-gray-600">Return</p>
                <p className="font-medium text-green-600">{formatCurrency(investment.returnAmount)}</p>
              </div>
            </div>
            
            {investment.startDate && (
              <div className="mt-3 pt-3 border-t border-gray-200">
                <p className="text-xs text-gray-500">
                  Dimulai: {new Date(investment.startDate).toLocaleDateString("id-ID")}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
