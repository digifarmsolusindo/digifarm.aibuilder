interface ProfileSectionProps {
  user: any;
}

export function ProfileSection({ user }: ProfileSectionProps) {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-gray-800 mb-4">Informasi Profil</h3>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center py-3 border-b border-gray-100">
          <span className="text-gray-600">Nama Lengkap</span>
          <span className="font-medium text-gray-800">{user?.name || "Belum diatur"}</span>
        </div>
        
        <div className="flex justify-between items-center py-3 border-b border-gray-100">
          <span className="text-gray-600">Email</span>
          <span className="font-medium text-gray-800">{user?.email}</span>
        </div>
        
        <div className="flex justify-between items-center py-3 border-b border-gray-100">
          <span className="text-gray-600">Status Email</span>
          <span className={`px-3 py-1 rounded-full text-sm ${
            user?.isEmailVerified 
              ? "bg-green-100 text-green-700" 
              : "bg-red-100 text-red-700"
          }`}>
            {user?.isEmailVerified ? "Terverifikasi" : "Belum Terverifikasi"}
          </span>
        </div>
        
        <div className="flex justify-between items-center py-3">
          <span className="text-gray-600">Bergabung Sejak</span>
          <span className="font-medium text-gray-800">
            {user?._creationTime ? new Date(user._creationTime).toLocaleDateString("id-ID") : "-"}
          </span>
        </div>
      </div>
    </div>
  );
}
