import { useState } from "react";

export function HelpSection() {
  const [activeTab, setActiveTab] = useState<"faq" | "policy">("faq");

  const faqData = [
    {
      question: "Apa itu DIGIFARM.Lite?",
      answer: "DIGIFARM.Lite adalah platform investasi ternak digital ayam petelur yang memungkinkan Anda berinvestasi dalam peternakan ayam tanpa harus memiliki lahan atau mengelola ternak secara langsung."
    },
    {
      question: "Bagaimana cara kerja investasi ternak digital?",
      answer: "Anda memilih paket investasi sesuai kemampuan, melakukan pembayaran, dan kami akan mengelola ternak ayam petelur untuk Anda. Return investasi akan diberikan sesuai dengan durasi dan paket yang dipilih."
    },
    {
      question: "Apakah investasi ini aman?",
      answer: "Ya, semua investasi dilengkapi dengan asuransi kematian ternak dan dikelola oleh tim profesional berpengalaman. Namun, seperti investasi lainnya, terdapat risiko yang perlu dipahami."
    },
    {
      question: "Bagaimana cara menarik return investasi?",
      answer: "Return investasi akan otomatis masuk ke saldo Anda setelah periode investasi berakhir. Anda dapat menarik saldo melalui fitur 'Tarik Saldo' di menu Portofolio."
    },
    {
      question: "Berapa minimum investasi?",
      answer: "Minimum investasi dimulai dari paket Peternak Junior dengan investasi Rp 243.920 untuk durasi 30 hari."
    }
  ];

  const policyData = [
    {
      title: "Syarat dan Ketentuan Umum",
      content: "Dengan menggunakan layanan DIGIFARM.Lite, Anda menyetujui untuk terikat dengan syarat dan ketentuan yang berlaku. Layanan ini hanya tersedia untuk pengguna yang berusia minimal 18 tahun dan memiliki kemampuan hukum penuh."
    },
    {
      title: "Kebijakan Investasi",
      content: "Semua investasi bersifat halal dan sesuai dengan prinsip syariah. Return investasi tidak dijamin dan dapat berubah sesuai kondisi pasar. Investor bertanggung jawab atas keputusan investasi yang diambil."
    },
    {
      title: "Kebijakan Pembayaran",
      content: "Pembayaran harus dilakukan sesuai dengan nominal yang tertera termasuk kode unik. Batas waktu pembayaran adalah 30 menit setelah transaksi dibuat. Pembayaran yang terlambat akan dibatalkan otomatis."
    },
    {
      title: "Kebijakan Penarikan",
      content: "Penarikan saldo dapat dilakukan setelah periode investasi berakhir. Proses penarikan membutuhkan waktu 1-3 hari kerja. Biaya administrasi penarikan sebesar Rp 2.500 per transaksi."
    },
    {
      title: "Kebijakan Privasi",
      content: "Kami berkomitmen melindungi data pribadi pengguna sesuai dengan peraturan yang berlaku. Data tidak akan dibagikan kepada pihak ketiga tanpa persetujuan pengguna."
    }
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-gray-800 mb-4">Bantuan</h3>
      
      {/* Tab Navigation */}
      <div className="flex bg-gray-100 rounded-lg p-1">
        <button
          onClick={() => setActiveTab("faq")}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === "faq"
              ? "bg-white text-gray-800 shadow-sm"
              : "text-gray-600 hover:text-gray-800"
          }`}
        >
          FAQ
        </button>
        <button
          onClick={() => setActiveTab("policy")}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === "policy"
              ? "bg-white text-gray-800 shadow-sm"
              : "text-gray-600 hover:text-gray-800"
          }`}
        >
          Kebijakan
        </button>
      </div>

      {/* Content */}
      <div className="space-y-4">
        {activeTab === "faq" && (
          <div className="space-y-4">
            {faqData.map((item, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-800 mb-2">{item.question}</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{item.answer}</p>
              </div>
            ))}
          </div>
        )}

        {activeTab === "policy" && (
          <div className="space-y-4">
            {policyData.map((item, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-800 mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600 leading-relaxed">{item.content}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Live Chat */}
      <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
        <div className="text-center">
          <div className="text-4xl mb-3">💬</div>
          <h4 className="font-bold text-blue-700 mb-2">Butuh Bantuan Lebih Lanjut?</h4>
          <p className="text-sm text-blue-600 mb-4">
            Tim customer service kami siap membantu Anda 24/7
          </p>
          <button className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors font-medium">
            Live Chat Agent
          </button>
        </div>
      </div>
    </div>
  );
}
