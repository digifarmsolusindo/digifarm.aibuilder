import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { InvestmentCategories } from "./InvestmentCategories";
import { InvestmentVariants } from "./InvestmentVariants";
import { ProductDetail } from "./ProductDetail";
import { PaymentPage } from "./PaymentPage";

export function MainDashboard() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<any>(null);
  const [currentInvestment, setCurrentInvestment] = useState<any>(null);
  const [showPayment, setShowPayment] = useState(false);

  const categories = useQuery(api.investments.getInvestmentCategories);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedVariant(null);
  };

  const handleVariantSelect = (variant: any) => {
    setSelectedVariant({ ...variant, category: selectedCategory });
  };

  const handleInvestmentCreate = (investment: any) => {
    setCurrentInvestment(investment);
    setShowPayment(true);
  };

  const handleBackToCategories = () => {
    setSelectedCategory(null);
    setSelectedVariant(null);
  };

  const handleBackToVariants = () => {
    setSelectedVariant(null);
  };

  const handleBackToDetail = () => {
    setShowPayment(false);
  };

  if (showPayment && currentInvestment) {
    return (
      <PaymentPage
        investment={currentInvestment}
        onBack={handleBackToDetail}
      />
    );
  }

  if (selectedVariant) {
    return (
      <ProductDetail
        variant={selectedVariant}
        onBack={handleBackToVariants}
        onInvest={handleInvestmentCreate}
      />
    );
  }

  if (selectedCategory) {
    return (
      <InvestmentVariants
        category={selectedCategory}
        onBack={handleBackToCategories}
        onVariantSelect={handleVariantSelect}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-600 via-amber-600 to-orange-600 bg-clip-text text-transparent mb-2">
          Pilih Kategori Investasi
        </h1>
        <p className="text-gray-600">Mulai investasi ternak digital sesuai kemampuan Anda</p>
      </div>

      <InvestmentCategories
        categories={categories || []}
        onCategorySelect={handleCategorySelect}
      />
    </div>
  );
}
