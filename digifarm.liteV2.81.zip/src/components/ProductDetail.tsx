import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface ProductDetailProps {
  variant: any;
  onBack: () => void;
  onInvest: (investment: any) => void;
}

export function ProductDetail({ variant, onBack, onInvest }: ProductDetailProps) {
  const createInvestment = useMutation(api.investments.createInvestment);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDuration = (days: number) => {
    if (days === 30) return "30 Hari (1 Bulan)";
    if (days === 90) return "90 Hari (3 Bulan)";
    if (days === 180) return "180 Hari (6 Bulan)";
    if (days === 365) return "365 Hari (12 Bulan)";
    return `${days} Hari`;
  };

  const getCategoryName = (category: string) => {
    const names = {
      junior: "Peternak Junior",
      muda: "Peternak Muda",
      senior: "Peternak Senior",
      juragan: "Juragan Ternak",
    };
    return names[category as keyof typeof names] || category;
  };

  const handleInvest = async () => {
    try {
      const result = await createInvestment({
        category: variant.category,
        duration: variant.duration,
        principal: variant.principal,
        returnAmount: variant.newReturn,
        chickens: variant.chickens,
      });

      onInvest({
        ...result,
        variant,
      });

      toast.success("Investasi berhasil dibuat!");
    } catch (error) {
      toast.error("Gagal membuat investasi");
      console.error(error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center hover:shadow-lg transition-shadow"
        >
          ←
        </button>
        <h2 className="text-xl font-bold text-gray-800">Detail Produk</h2>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-lg border border-yellow-100">
        <div className="text-center mb-6">
          <div className="text-6xl mb-4">🐓</div>
          <h3 className="text-2xl font-bold text-gray-800 mb-2">
            {getCategoryName(variant.category)}
          </h3>
          <p className="text-gray-600">{formatDuration(variant.duration)}</p>
        </div>

        <div className="space-y-4 mb-6">
          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 p-4 rounded-xl">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-700 font-medium">Harga Paket:</span>
              <span className="text-2xl font-bold text-gray-800">
                {formatCurrency(variant.principal)}
              </span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-700 font-medium">Jumlah Return:</span>
              <div className="text-right">
                {variant.hasPromo && (
                  <div className="text-sm text-gray-400 line-through">
                    {formatCurrency(variant.oldReturn)}
                  </div>
                )}
                <div className="text-2xl font-bold text-green-600 flex items-center">
                  {formatCurrency(variant.newReturn)}
                  {variant.hasPromo && (
                    <span className="ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                      PROMO
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-xl">
            <div className="flex justify-between items-center">
              <span className="text-gray-700 font-medium">Keuntungan:</span>
              <span className="text-xl font-bold text-blue-600">
                {formatCurrency(variant.newReturn - variant.principal)}
              </span>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <h4 className="font-medium text-gray-700 mb-2">Detail Paket:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• {variant.chickens} Ekor Ayam Petelur</li>
              <li>• Paket Pakan {formatDuration(variant.duration).split(" ")[2]}</li>
              <li>• Biaya layanan dan asuransi kematian</li>
              <li>• Monitoring 24/7</li>
            </ul>
          </div>

          {variant.hasPromo && (
            <div className="bg-red-50 border border-red-200 p-4 rounded-xl">
              <div className="flex items-center space-x-2">
                <span className="text-red-600">🎉</span>
                <span className="text-red-700 font-medium">
                  Promo Khusus Transaksi Pertama!
                </span>
              </div>
              <p className="text-sm text-red-600 mt-1">
                Dapatkan return lebih tinggi untuk investasi pertama Anda
              </p>
            </div>
          )}
        </div>

        <button
          onClick={handleInvest}
          className="w-full bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-white font-bold py-4 rounded-xl hover:shadow-lg transition-all duration-300 text-lg"
        >
          Bayar Sekarang
        </button>
      </div>
    </div>
  );
}
