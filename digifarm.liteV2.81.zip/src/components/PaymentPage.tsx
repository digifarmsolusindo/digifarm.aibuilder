import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface PaymentPageProps {
  investment: any;
  onBack: () => void;
}

export function PaymentPage({ investment, onBack }: PaymentPageProps) {
  const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes in seconds
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);

  const transaction = useQuery(api.transactions.getTransaction, {
    investmentId: investment.investmentId,
  });
  const confirmPayment = useMutation(api.transactions.confirmPayment);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const handleConfirmPayment = async () => {
    try {
      await confirmPayment({ investmentId: investment.investmentId });
      setPaymentConfirmed(true);
      toast.success("Konfirmasi pembayaran berhasil!");
    } catch (error) {
      toast.error("Gagal konfirmasi pembayaran");
      console.error(error);
    }
  };

  if (!transaction) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600">Memuat data transaksi...</p>
      </div>
    );
  }

  if (timeLeft === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center hover:shadow-lg transition-shadow"
          >
            ←
          </button>
          <h2 className="text-xl font-bold text-gray-800">Pembayaran</h2>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg border border-red-200">
          <div className="text-center">
            <div className="text-6xl mb-4">⏰</div>
            <h3 className="text-xl font-bold text-red-600 mb-2">Waktu Pembayaran Habis</h3>
            <p className="text-gray-600 mb-4">
              Batas waktu pembayaran telah berakhir. Silakan buat transaksi baru.
            </p>
            <button
              onClick={onBack}
              className="bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-white font-bold py-3 px-6 rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Kembali
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center hover:shadow-lg transition-shadow"
        >
          ←
        </button>
        <h2 className="text-xl font-bold text-gray-800">Pembayaran</h2>
      </div>

      {/* Timer */}
      <div className="bg-red-50 border border-red-200 p-4 rounded-xl">
        <div className="text-center">
          <p className="text-red-700 font-medium mb-2">Batas Waktu Pembayaran</p>
          <div className="text-3xl font-bold text-red-600">{formatTime(timeLeft)}</div>
        </div>
      </div>

      {/* Bank Logo and Payment Details */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-yellow-100">
        <div className="text-center mb-6">
          <div className="bg-blue-600 text-white text-2xl font-bold py-4 px-8 rounded-xl mb-4">
            BCA
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2">Transfer Bank BCA</h3>
        </div>

        <div className="space-y-4">
          <div className="bg-yellow-50 p-4 rounded-xl">
            <div className="text-center">
              <p className="text-gray-700 font-medium mb-2">Total Pembayaran</p>
              <div className="text-3xl font-bold text-gray-800">
                {formatCurrency(transaction.amount)}
              </div>
              <p className="text-sm text-gray-600 mt-1">
                (Termasuk kode unik: {transaction.uniqueCode})
              </p>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl">
            <h4 className="font-medium text-gray-700 mb-3">Cara Pembayaran:</h4>
            <div className="space-y-2 text-sm text-gray-600">
              <p>1. Transfer ke rekening berikut:</p>
              <div className="bg-white p-3 rounded-lg border">
                <p className="font-bold text-gray-800">8692317822</p>
                <p className="text-gray-600">PT Lazia Cahya Indonesia</p>
              </div>
              <p>2. Transfer tepat sesuai nominal di atas</p>
              <p>3. Klik "Konfirmasi Pembayaran" setelah transfer</p>
              <p>4. Tunggu verifikasi dari admin (maks 1x24 jam)</p>
            </div>
          </div>

          {paymentConfirmed ? (
            <div className="bg-green-50 border border-green-200 p-4 rounded-xl">
              <div className="text-center">
                <div className="text-4xl mb-2">✅</div>
                <h4 className="font-bold text-green-700 mb-2">Menunggu Konfirmasi</h4>
                <p className="text-sm text-green-600">
                  Pembayaran Anda sedang diverifikasi oleh admin. Kami akan mengirim notifikasi setelah pembayaran dikonfirmasi.
                </p>
              </div>
            </div>
          ) : (
            <button
              onClick={handleConfirmPayment}
              className="w-full bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 text-white font-bold py-4 rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Konfirmasi Pembayaran
            </button>
          )}
        </div>
      </div>

      {/* Payment Instructions */}
      <div className="bg-blue-50 p-4 rounded-xl">
        <h4 className="font-medium text-blue-700 mb-2">⚠️ Penting:</h4>
        <ul className="text-sm text-blue-600 space-y-1">
          <li>• Transfer harus sesuai nominal yang tertera</li>
          <li>• Jangan lupa klik "Konfirmasi Pembayaran"</li>
          <li>• Simpan bukti transfer untuk keperluan verifikasi</li>
          <li>• Hubungi customer service jika ada kendala</li>
        </ul>
      </div>
    </div>
  );
}
