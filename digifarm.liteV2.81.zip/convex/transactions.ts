import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getTransaction = query({
  args: { investmentId: v.id("investments") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const user = await ctx.db.get(userId);
    if (!user) return null;

    const appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", user.email || ""))
      .first();

    if (!appUser) return null;

    return await ctx.db
      .query("transactions")
      .withIndex("by_investment", (q) => q.eq("investmentId", args.investmentId))
      .first();
  },
});

export const confirmPayment = mutation({
  args: { investmentId: v.id("investments") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const user = await ctx.db.get(userId);
    if (!user) throw new Error("User not found");

    const appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", user.email || ""))
      .first();

    if (!appUser) throw new Error("User profile not found");

    const transaction = await ctx.db
      .query("transactions")
      .withIndex("by_investment", (q) => q.eq("investmentId", args.investmentId))
      .first();

    if (!transaction) throw new Error("Transaction not found");

    // Check if payment deadline has passed
    if (Date.now() > transaction.paymentDeadline) {
      await ctx.db.patch(transaction._id, { status: "expired" });
      throw new Error("Payment deadline has passed");
    }

    await ctx.db.patch(transaction._id, {
      status: "confirmed",
      confirmationTime: Date.now(),
    });

    return transaction._id;
  },
});

export const sendPaymentNotification = action({
  args: {
    investmentId: v.id("investments"),
    userEmail: v.string(),
    amount: v.number(),
  },
  handler: async (ctx, args) => {
    // This will send email to admin for payment verification
    console.log(`Payment notification sent for investment ${args.investmentId}`);
    return true;
  },
});
