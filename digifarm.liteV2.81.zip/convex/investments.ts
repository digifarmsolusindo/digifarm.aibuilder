import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getInvestmentCategories = query({
  args: {},
  handler: async (ctx) => {
    return [
      {
        id: "junior",
        name: "Peternak Junior",
        icon: "🐣",
        description: "Mulai investasi dengan modal kecil",
      },
      {
        id: "muda",
        name: "Peternak Muda",
        icon: "🐤",
        description: "Investasi menengah untuk hasil optimal",
      },
      {
        id: "senior",
        name: "Peternak Senior",
        icon: "🐓",
        description: "Investasi besar dengan return maksimal",
      },
      {
        id: "juragan",
        name: "Juragan Ternak",
        icon: "👑",
        description: "Investasi premium untuk juragan sejati",
      },
    ];
  },
});

export const getInvestmentVariants = query({
  args: { category: v.string() },
  handler: async (ctx, args) => {
    const variants = {
      junior: [
        {
          duration: 30,
          principal: 243920,
          oldReturn: 252776,
          newReturn: 260359,
          chickens: 2,
          hasPromo: true,
        },
        {
          duration: 90,
          principal: 391760,
          oldReturn: 418328,
          newReturn: 451794,
          chickens: 2,
          hasPromo: true,
        },
        {
          duration: 180,
          principal: 613520,
          oldReturn: 666656,
          newReturn: 733322,
          chickens: 2,
          hasPromo: true,
        },
      ],
      muda: [
        {
          duration: 90,
          principal: 1767000,
          oldReturn: 1882840,
          newReturn: 1899840,
          chickens: 10,
          hasPromo: true,
        },
        {
          duration: 180,
          principal: 2667000,
          oldReturn: 2915680,
          newReturn: 2941180,
          chickens: 10,
          hasPromo: true,
        },
        {
          duration: 365,
          principal: 4517000,
          oldReturn: 5038740,
          newReturn: 5038740,
          chickens: 10,
          hasPromo: false,
        },
      ],
      senior: [
        {
          duration: 90,
          principal: 8835000,
          oldReturn: 9414200,
          newReturn: 9414200,
          chickens: 50,
          hasPromo: false,
        },
        {
          duration: 180,
          principal: 13335000,
          oldReturn: 14578400,
          newReturn: 14578400,
          chickens: 50,
          hasPromo: false,
        },
        {
          duration: 365,
          principal: 22585000,
          oldReturn: 25193700,
          newReturn: 25193700,
          chickens: 50,
          hasPromo: false,
        },
      ],
      juragan: [
        {
          duration: 90,
          principal: 17670000,
          oldReturn: 18828400,
          newReturn: 18828400,
          chickens: 100,
          hasPromo: false,
        },
        {
          duration: 180,
          principal: 26670000,
          oldReturn: 29156800,
          newReturn: 29156800,
          chickens: 100,
          hasPromo: false,
        },
        {
          duration: 365,
          principal: 45170000,
          oldReturn: 50387400,
          newReturn: 50387400,
          chickens: 100,
          hasPromo: false,
        },
      ],
    };

    return variants[args.category as keyof typeof variants] || [];
  },
});

export const createInvestment = mutation({
  args: {
    category: v.string(),
    duration: v.number(),
    principal: v.number(),
    returnAmount: v.number(),
    chickens: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const user = await ctx.db.get(userId);
    if (!user) throw new Error("User not found");

    const appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", user.email || ""))
      .first();

    if (!appUser) throw new Error("User profile not found");

    const transactionId = `TXN${Date.now()}${Math.floor(Math.random() * 1000)}`;

    const investmentId = await ctx.db.insert("investments", {
      userId: appUser._id,
      category: args.category,
      duration: args.duration,
      principal: args.principal,
      returnAmount: args.returnAmount,
      chickens: args.chickens,
      status: "pending",
      transactionId,
    });

    // Create transaction
    const uniqueCode = Math.floor(Math.random() * 999) + 1;
    const paymentDeadline = Date.now() + (30 * 60 * 1000); // 30 minutes

    await ctx.db.insert("transactions", {
      userId: appUser._id,
      investmentId,
      amount: args.principal + uniqueCode,
      uniqueCode,
      status: "pending",
      paymentDeadline,
    });

    return { investmentId, transactionId };
  },
});

export const getUserInvestments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const user = await ctx.db.get(userId);
    if (!user) return [];

    const appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", user.email || ""))
      .first();

    if (!appUser) return [];

    return await ctx.db
      .query("investments")
      .withIndex("by_user", (q) => q.eq("userId", appUser._id))
      .collect();
  },
});
