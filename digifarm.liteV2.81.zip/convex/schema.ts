import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  users: defineTable({
    email: v.string(),
    name: v.optional(v.string()),
    profileImage: v.optional(v.string()),
    isEmailVerified: v.boolean(),
    verificationToken: v.optional(v.string()),
    resetPasswordToken: v.optional(v.string()),
    resetPasswordExpires: v.optional(v.number()),
  }).index("by_email", ["email"])
    .index("by_verification_token", ["verificationToken"])
    .index("by_reset_token", ["resetPasswordToken"]),

  investments: defineTable({
    userId: v.id("users"),
    category: v.string(), // "junior", "muda", "senior", "juragan"
    duration: v.number(), // in days
    principal: v.number(),
    returnAmount: v.number(),
    chickens: v.number(),
    status: v.string(), // "pending", "active", "completed"
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    transactionId: v.string(),
  }).index("by_user", ["userId"])
    .index("by_transaction", ["transactionId"]),

  transactions: defineTable({
    userId: v.id("users"),
    investmentId: v.id("investments"),
    amount: v.number(),
    uniqueCode: v.number(),
    status: v.string(), // "pending", "confirmed", "expired"
    paymentDeadline: v.number(),
    confirmationTime: v.optional(v.number()),
  }).index("by_user", ["userId"])
    .index("by_investment", ["investmentId"]),

  portfolios: defineTable({
    userId: v.id("users"),
    totalInvestment: v.number(),
    totalReturn: v.number(),
    activeInvestments: v.number(),
    completedInvestments: v.number(),
    availableBalance: v.number(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
