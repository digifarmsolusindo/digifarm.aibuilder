import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getCurrentUser = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    
    const user = await ctx.db.get(userId);
    if (!user) return null;

    // Get user from application users table
    const appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", user.email || ""))
      .first();

    return {
      ...user,
      ...appUser,
    };
  },
});

export const createUserProfile = mutation({
  args: {
    email: v.string(),
    name: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const existingUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", args.email))
      .first();

    if (existingUser) return existingUser._id;

    return await ctx.db.insert("users", {
      email: args.email,
      name: args.name,
      isEmailVerified: false,
    });
  },
});

export const updateProfile = mutation({
  args: {
    name: v.optional(v.string()),
    profileImage: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const user = await ctx.db.get(userId);
    if (!user) throw new Error("User not found");

    const appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", user.email || ""))
      .first();

    if (!appUser) throw new Error("User profile not found");

    await ctx.db.patch(appUser._id, {
      name: args.name,
      profileImage: args.profileImage,
    });

    return appUser._id;
  },
});

export const sendVerificationEmail = action({
  args: {
    email: v.string(),
    token: v.string(),
  },
  handler: async (ctx, args) => {
    // This will be implemented with email service
    console.log(`Verification email sent to ${args.email} with token ${args.token}`);
    return true;
  },
});
